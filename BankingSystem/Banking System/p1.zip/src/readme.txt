Hey. so apparently i had some validation issues in the previous file due to which it did not run the Test properly, but i talked with the professor about it and he asked me to submit the new fixed files, 

I noticed that the main issue was that. my account numbers were starting from 10000 instead of 1000, So i am attaching a new set of files, BankingSystem.java, Create.sql, P1.java, db.properties, BankingUI.java, and this readme file, alongwith the batchInputProcessor.java and the jdbc driver.

I am attaching everything in a zip file, simply unzip it and run it in the same directory and it should be working:

Kindly consider, and also i would mention the steps below to run it, just in case:

			- javac p1.java
			- java -cp ":./db2jcc4.jar" P1 db.properties

Thank You and i really appreciate the effort. 